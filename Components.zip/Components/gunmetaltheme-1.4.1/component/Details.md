To style your app with this theme, call
`GunmetalTheme.Apply` from your AppDelegate's `FinishedLaunching` method:

```csharp
using Xamarin.Themes;
...

public override bool FinishedLaunching (UIApplication app, NSDictionary options)
{
	...
	GunmetalTheme.Apply ();
}
```
 
*Screenshot assembled with [PlaceIt](http://placeit.breezi.com/).*
