// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//

#if __UNIFIED__
using Foundation;
#else
using MonoTouch.Foundation;
#endif

namespace ThemeSample
{
	[Register ("ListViewController")]
	partial class ListViewController
	{
		
		void ReleaseDesignerOutlets ()
		{
		}
	}
}
