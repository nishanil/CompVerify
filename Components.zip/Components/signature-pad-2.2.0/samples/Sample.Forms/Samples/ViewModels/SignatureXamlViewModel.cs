﻿namespace Samples.ViewModels
{
	public class SignatureXamlViewModel : BaseViewModel
	{
	}
}
