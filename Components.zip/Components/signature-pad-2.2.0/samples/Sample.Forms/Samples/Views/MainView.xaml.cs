﻿using Xamarin.Forms;

namespace Samples.Views
{
	public partial class MainView : ContentPage
	{
		public MainView ()
		{
			InitializeComponent ();
		}
	}
}
