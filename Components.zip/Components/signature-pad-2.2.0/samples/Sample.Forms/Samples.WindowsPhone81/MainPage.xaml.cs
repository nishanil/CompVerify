﻿
namespace Samples.WindowsPhone81
{
	public sealed partial class MainPage
	{
		public MainPage ()
		{
			this.InitializeComponent ();

			LoadApplication (new Samples.App ());
		}
	}
}
