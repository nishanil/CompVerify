﻿namespace Samples.UWP
{
	public sealed partial class MainPage
	{
		public MainPage ()
		{
			InitializeComponent ();

			LoadApplication (new Samples.App ());
		}
	}
}
