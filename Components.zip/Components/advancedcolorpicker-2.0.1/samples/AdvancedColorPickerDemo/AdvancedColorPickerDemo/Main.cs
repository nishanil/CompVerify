﻿using UIKit;

namespace AdvancedColorPickerDemo
{
	public class Application
	{
		static void Main(string[] args)
		{
			UIApplication.Main(args, null, typeof(AppDelegate));
		}
	}
}
